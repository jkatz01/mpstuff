
/* PfPP Tim/Bev/Ber p. 278*/

#include <stdio.h>
#include "memory.h"
#include "mpi.h"

#define pnl printf("\n")
#define pcm printf(",")

void print_buffer(long a[], int len){
    int i;  
    pnl; pnl;
    printf("[");
    for(i=0; i<len; i++){
        printf("%ld",a[i]);
        if (i<len-1) {
            pcm;
        }
    }
    printf("]");
    pnl; pnl;
}


int main(int argc, char **argv) {
      int Tag1 = 1; 
      int Tag2 = 2; 
      int num_procs; 
      int ID;
      int buffer_count = 100;
      long *buffer;
      int i;
      MPI_Status stat;

      MPI_Init(&argc, &argv); 

      MPI_Comm_size (MPI_COMM_WORLD, &num_procs);
      MPI_Comm_rank (MPI_COMM_WORLD, &ID);

      if (num_procs != 2) MPI_Abort(MPI_COMM_WORLD, 1);

      buffer = (long *)malloc(buffer_count*sizeof(long));

      for (i=0; i<buffer_count; i++) 
         buffer[i] = (long)i; 

      if (ID == 0) {
         MPI_Send(buffer, buffer_count, MPI_LONG, 1, Tag1, MPI_COMM_WORLD);
         MPI_Recv(buffer, buffer_count, MPI_LONG, 1, Tag2, MPI_COMM_WORLD, &stat);
         print_buffer(buffer,buffer_count);
      }
      else {
         MPI_Recv(buffer, buffer_count, MPI_LONG, 0, Tag1, MPI_COMM_WORLD, &stat);
         MPI_Send(buffer, buffer_count, MPI_LONG, 0, Tag2, MPI_COMM_WORLD);
	 print_buffer(buffer,buffer_count);
      }

      MPI_Finalize();
}
